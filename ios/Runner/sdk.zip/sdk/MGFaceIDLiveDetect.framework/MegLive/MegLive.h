//
//  MegLive.h
//  MegLive
//
//  Created by MegviiDev on 2017/9/7.
//  Copyright © 2017年 megvii. All rights reserved.
//

#ifndef MegLive_h
#define MegLive_h

#import "MegFaceIDSelectedImageItem.h"
#import "MGFaceIDQualityFrameRectItem.h"
#import "MGFaceIDQualityResultFrameItem.h"
#import "MegFaceIDConfig.h"
#import "MegFaceIDDetectJSONManager.h"
#import "json.hpp"

#import "MegFaceIDSilentLiveManager.h"
#import "MegFaceIDSilentLiveConfig.h"

#import "MegFaceIDActionLiveManager.h"
#import "MegFaceIDActionLiveConfig.h"
#import "MegFaceIDActionLiveActionManager.h"

#endif /* MegLive_h */
