//
//  MGFaceIDQualityFrameRectItem.h
//  MegLookMirror
//
//  Created by MegviiDev on 2017/8/15.
//  Copyright © 2017年 megvii. All rights reserved.
//

#ifndef _MG_RelativeRect_H_
#define _MG_RelativeRect_H_

typedef struct RelativeRect {
    float x;
    float y;
    float width;
    float height;
} RelativeRect;

#endif
