//
//  MGFaceIDLiveDetect.h
//  MGFaceIDLiveDetect
//
//  Created by Megvii on 2018/10/16.
//  Copyright © 2018 Megvii. All rights reserved.
//

#import <MGFaceIDLiveDetect/MGFaceIDLiveDetectManager.h>
#import <MGFaceIDLiveDetect/MGFaceIDLiveDetectError.h>
#import <MGFaceIDLiveDetect/MGFaceIDLiveDetectConfig.h>
#import <MGFaceIDLiveDetect/MGFaceIDLiveDetectCustomConfigItem.h>
#import <MGFaceIDLiveDetect/MGFaceIDLiveDetectLanguageConfig.h>
