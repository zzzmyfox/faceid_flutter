//
//  MGAliyunOSSKit.h
//  MGFaceIDBaseKit
//
//  Created by MegviiDev on 2018/6/11.
//  Copyright © 2018年 Megvii. All rights reserved.
//

#import <MGFaceIDBaseKit/MGALog.h>
#import <MGFaceIDBaseKit/MGALogGroup.h>
#import <MGFaceIDBaseKit/MGALogClient.h>
