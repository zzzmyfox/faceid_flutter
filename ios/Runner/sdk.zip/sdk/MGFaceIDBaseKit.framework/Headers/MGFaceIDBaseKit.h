//
//  MGFaceIDBaseKit.h
//  MGFaceIDBaseKit
//
//  Created by MegviiDev on 2018/6/11.
//  Copyright © 2018年 Megvii. All rights reserved.
//

#import <MGFaceIDBaseKit/MGCameraKit.h>
#import <MGFaceIDBaseKit/MGAliyunOSSKit.h>
#import <MGFaceIDBaseKit/MGFaceIDLicenseManager.h>
