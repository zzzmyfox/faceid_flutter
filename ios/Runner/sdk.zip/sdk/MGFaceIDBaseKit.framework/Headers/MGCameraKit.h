//
//  MGCameraManagerHeader.h
//  MGFaceIDGeneralModule
//
//  Created by MegviiDev on 2018/5/18.
//  Copyright © 2018年 Megvii. All rights reserved.
//

#import <MGFaceIDBaseKit/MGCameraManager.h>
#import <MGFaceIDBaseKit/MGFaceIDCameraManager.h>
#import <MGFaceIDBaseKit/MGCameraImage.h>
#import <MGFaceIDBaseKit/MGCameraDelegate.h>
#import <MGFaceIDBaseKit/MGCameraConfig.h>
#import <MGFaceIDBaseKit/MGCameraDeviceSupport.h>
